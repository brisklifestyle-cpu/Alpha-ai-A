package com.alphaai.devilbreath

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFE32636)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFF9A9A9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlphaApp() }
    }
}

@Composable
fun AlphaApp() {
    var tab by remember { mutableStateOf("Home") }
    var module by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF101010)) {
                listOf(Triple("Home", Icons.Default.Home, "Home"), Triple("Devices", Icons.Default.Tv, "Devices"), Triple("Devil", Icons.Default.Mic, "Devil"), Triple("Settings", Icons.Default.Settings, "Settings")).forEach { (label, icon, route) ->
                    NavigationBarItem(selected = tab == route && module == null, onClick = { tab = route; module = null }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Red, indicatorColor = Color(0xFF351116), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            if (module != null) ModuleScreen(module!!, Modifier.padding(padding))
            else when (tab) {
                "Home" -> HomeScreen(Modifier.padding(padding)) { module = it }
                "Devices" -> ModuleScreen("Device Command Center", Modifier.padding(padding), listOf("Hisense 43A6Q • VIDAA TV", "ONN TV Box • Google TV", "Ultimate Ears MEGABOOM 3", "Android Phone"))
                "Devil" -> DevilScreen(Modifier.padding(padding))
                else -> ModuleScreen("AI Settings", Modifier.padding(padding), listOf("Language: বাংলা / English", "Voice: Deep Cinematic", "Wake phrase: Hey Devil", "Online / Offline mode", "Permissions & integrations"))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, open: (String) -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column {
            Text("ALPHA AI", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("DEVIL BREATH", color = Red, fontSize = 11.sp, letterSpacing = 2.sp)
        }
        Surface(color = Color(0xFF1A0B0D), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("HELLO, DEVIL", color = Red, fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                Text("Your command center.", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("আপনার ডিভাইস ও স্মার্ট টুল পরিচালনার কেন্দ্র।", color = Muted, fontSize = 13.sp)
                Button(onClick = { open("Devil Breath") }, colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("ACTIVATE DEVIL") }
            }
        }
        Heading("DEVICE COMMAND CENTER")
        DeviceRow("Hisense 43A6Q", "VIDAA TV • Setup required", Icons.Default.Tv)
        DeviceRow("ONN TV Box", "Google TV • Setup required", Icons.Default.LiveTv)
        DeviceRow("MEGABOOM 3", "Bluetooth speaker • Setup required", Icons.Default.Speaker)
        DeviceRow("Android Phone", "Phone manager", Icons.Default.PhoneAndroid)
        Heading("SMART TOOLS")
        val entries = listOf("TV Control" to Icons.Default.Tv, "Sound Studio" to Icons.Default.GraphicEq, "Phone Manager" to Icons.Default.PhoneAndroid, "Social Media Manager" to Icons.Default.Groups, "Backup Manager" to Icons.Default.CloudUpload, "Truecaller Integration" to Icons.Default.Call)
        entries.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { pair.forEach { (name, icon) -> ToolCard(name, icon, Modifier.weight(1f)) { open(name) } }; if (pair.size == 1) Spacer(Modifier.weight(1f)) } }
        Text("বাস্তব ডিভাইস সংযোগ ও অনুমতি পরবর্তী ধাপে যুক্ত হবে।", color = Muted, fontSize = 11.sp)
    }
}

@Composable fun Heading(value: String) { Text(value, color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }

@Composable
fun DeviceRow(name: String, status: String, icon: ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Red); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(name, color = White, fontWeight = FontWeight.SemiBold); Text(status, color = Muted, fontSize = 11.sp) }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
fun ToolCard(name: String, icon: ImageVector, modifier: Modifier = Modifier, click: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier.height(104.dp).clickable { click() }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(icon, null, tint = Red); Text(name, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun ModuleScreen(title: String, modifier: Modifier = Modifier, rows: List<String> = emptyList()) {
    val content = if (rows.isNotEmpty()) rows else when (title) {
        "Sound Studio" -> listOf("International Hi-Fi", "International Bass", "International Vocal", "International Boom", "Cinematic", "Broadcast", "Sports", "Night", "Custom EQ • Neutral default")
        "Backup Manager" -> listOf("Local phone backup", "Google Drive", "OneDrive / Dropbox (planned)", "Backup history", "Restore tools")
        "Social Media Manager" -> listOf("Instagram", "Facebook", "YouTube", "TikTok", "App permissions and usage")
        "Phone Manager" -> listOf("App permissions", "Storage overview", "Notification settings", "Truecaller integration")
        "Truecaller Integration" -> listOf("Connection status", "Caller ID setup status", "Spam protection status", "Open Truecaller settings")
        "TV Control" -> listOf("Hisense 43A6Q • VIDAA", "ONN TV Box • Google TV", "Network setup required")
        else -> listOf("Setup required", "Integration will be added in a later build")
    }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ALPHA AI", color = Red, fontSize = 12.sp, letterSpacing = 3.sp)
        Text(title, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        content.forEach { item -> Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(item, color = White, modifier = Modifier.weight(1f), fontSize = 14.sp); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
        Text("এটি প্রাথমিক কাঠামো। বাস্তব সংযোগ, ডেটা ব্যাকআপ ও নিয়ন্ত্রণ আলাদা API/অনুমতি এবং পরীক্ষা সাপেক্ষ।", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun DevilScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("DEVIL BREATH", color = Red, fontSize = 12.sp, letterSpacing = 3.sp)
        Text("Hey Devil.", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("ভয়েস অ্যাসিস্ট্যান্টের প্রাথমিক কন্ট্রোল প্যানেল।", color = Muted)
        Surface(color = Color(0xFF1A0B0D), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Mic, null, tint = Red, modifier = Modifier.size(48.dp))
                Text("VOICE ASSISTANT", color = White, fontWeight = FontWeight.Bold)
                Text("মাইক্রোফোন ও always-on wake word এখনো সংযুক্ত নয়।", color = Muted, fontSize = 12.sp)
                Button(onClick = {}, enabled = false) { Text("MIC SETUP — COMING NEXT") }
            }
        }
    }
}
