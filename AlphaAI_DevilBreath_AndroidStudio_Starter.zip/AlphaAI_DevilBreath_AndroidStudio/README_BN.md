# Alpha AI — Devil Breath

এটি Android Studio-তে খোলার উপযোগী একটি **starter project**; এটি এখনো কম্পাইল করা APK নয়।

## অন্তর্ভুক্ত
- Premium black / white / red dashboard
- Home, Devices, Devil, Settings navigation
- Hisense 43A6Q, ONN TV Box, MEGABOOM 3 ও Android Phone-এর device tiles
- TV Control, Sound Studio, Phone Manager, Social Media Manager, Backup Manager ও Truecaller Integration-এর প্রাথমিক স্ক্রিন
- Devil Breath voice assistant-এর প্রাথমিক স্ক্রিন

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই starter build-এ বাস্তব TV/স্পিকার নিয়ন্ত্রণ, Truecaller caller-ID service, ক্লাউড ব্যাকআপ, পূর্ণ ফোন ক্লোন, সোশ্যাল অ্যাপ পরিচালনা, মাইক্রোফোন বা “Hey Devil” wake-word চালু করা হয়নি। এগুলোর জন্য পৃথক Android API, অনুমতি, সংশ্লিষ্ট সেবার সমর্থন ও ডিভাইস-পরীক্ষা প্রয়োজন। সাধারণ Android অ্যাপ পুরো OS বা সব অ্যাপের private data ক্লোন করতে পারে না।

## APK বানানোর ধাপ (কম্পিউটারে Android Studio প্রয়োজন)
1. ZIP ফাইলটি Extract করুন।
2. Android Studio-তে `AlphaAI_DevilBreath_AndroidStudio` ফোল্ডার Open করুন।
3. Gradle Sync সম্পন্ন হতে দিন।
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** চাপুন।
5. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk`-এ।

প্রয়োজন: সাম্প্রতিক Android Studio, JDK 17, Android SDK Platform 35।
Package: `com.alphaai.devilbreath` | Minimum Android: 6.0 (API 23)
